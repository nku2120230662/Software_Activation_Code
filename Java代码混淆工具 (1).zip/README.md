# Java代码混淆和加壳工具

这是一个基于Java和Spring Boot的软件加壳和混淆工具，可以保护Java代码免受逆向工程的侵害，同时保持原有功能不变。

## 功能特点

- **名称混淆**：重命名类、方法和变量，使反编译后的代码难以理解
- **控制流混淆**：修改程序的执行流程，增加代码复杂度，阻碍静态分析
- **字符串加密**：加密代码中的字符串常量，防止敏感信息泄露
- **代码加壳**：为应用程序添加保护层，防止直接访问和修改字节码
- **资源加密**：加密应用程序中的资源文件，防止未授权访问
- **反调试保护**：检测和防止调试器附加，增强运行时安全性

## 技术栈

### 前端
- React
- Axios
- React Router
- React Toastify
- Font Awesome

### 后端
- Spring Boot
- ASM (字节码操作)
- ProGuard Core
- Apache Commons

## 项目结构

```
java-obfuscator/
├── frontend/                # React前端应用
│   ├── public/              # 静态资源
│   ├── src/                 # 源代码
│   │   ├── components/      # React组件
│   │   ├── pages/           # 页面组件
│   │   ├── services/        # API服务
│   │   ├── styles/          # CSS样式
│   │   └── utils/           # 工具函数
│   └── package.json         # 依赖配置
├── backend/                 # Spring Boot后端应用
│   ├── src/                 # 源代码
│   │   ├── main/
│   │   │   ├── java/        # Java代码
│   │   │   └── resources/   # 配置文件
│   │   └── test/            # 测试代码
│   └── pom.xml              # Maven配置
├── docker-compose.yml       # Docker Compose配置
└── README.md                # 项目说明
```

## 安装和运行

### 前端

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

### 后端

```bash
# 进入后端目录
cd backend

# 构建项目
mvn clean package

# 运行应用
java -jar target/java-obfuscator-0.0.1-SNAPSHOT.jar
```

### 使用Docker Compose

```bash
# 构建并启动所有服务
docker-compose up -d

# 停止所有服务
docker-compose down
```

## 使用方法

1. 访问应用首页：`http://localhost:3001`
2. 导航到"混淆工具"页面
3. 上传Java源代码(.java)或编译后的文件(.class, .jar, .war)
4. 配置混淆选项
5. 点击"开始混淆"按钮
6. 下载混淆后的文件

## API文档

后端提供以下API端点：

- `GET /api/status` - 获取服务器状态
- `GET /api/options` - 获取可用的混淆选项
- `POST /api/obfuscate` - 上传并混淆代码

详细的API文档请参考后端的README文件。

## 贡献指南

1. Fork项目
2. 创建特性分支：`git checkout -b feature/amazing-feature`
3. 提交更改：`git commit -m 'Add some amazing feature'`
4. 推送到分支：`git push origin feature/amazing-feature`
5. 提交Pull Request

## 许可证

本项目采用MIT许可证 - 详情请参阅LICENSE文件
