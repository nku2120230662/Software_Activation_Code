#!/bin/bash

# 创建必要的目录
mkdir -p temp output

# 编译项目
echo "正在编译Java混淆器后端..."
./mvnw clean package -DskipTests

# 检查编译结果
if [ $? -eq 0 ]; then
    echo "编译成功！"
    echo "可以使用以下命令运行应用："
    echo "java -jar target/java-obfuscator-0.0.1-SNAPSHOT.jar"
else
    echo "编译失败，请检查错误信息。"
fi
