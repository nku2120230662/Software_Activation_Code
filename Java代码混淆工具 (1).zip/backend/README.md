# Java Obfuscator Backend

This is the backend service for the Java Obfuscator application. It provides REST APIs for obfuscating Java code, including source files (.java), class files (.class), and archives (.jar, .war).

## Features

- Java code obfuscation with multiple techniques:
  - Name obfuscation (variables, classes, packages)
  - Control flow obfuscation
  - String encryption
  - Debug information removal
  - Dead code insertion
  - Resource encryption
- REST API for integration with frontend or other services
- Support for various Java file formats
- Configurable obfuscation settings

## Requirements

- Java 11 or higher
- Maven 3.6 or higher

## Building the Application

```bash
mvn clean package
```

## Running the Application

```bash
java -jar target/java-obfuscator-0.0.1-SNAPSHOT.jar
```

Or using Maven:

```bash
mvn spring-boot:run
```

## API Documentation

The application exposes the following REST APIs:

### Get Server Status

```
GET /api/status
```

Returns the current status of the server.

### Get Obfuscation Options

```
GET /api/options
```

Returns the available obfuscation options and features.

### Obfuscate Code

```
POST /api/obfuscate
```

Uploads a Java file and applies obfuscation according to the specified settings.

## Configuration

The application can be configured using the `application.properties` file:

- `server.port`: The port on which the server runs (default: 8080)
- `obfuscator.temp-dir`: Directory for temporary files
- `obfuscator.output-dir`: Directory for output files
- `obfuscator.default-level`: Default obfuscation level

## Docker Support

A Dockerfile is provided to containerize the application:

```bash
# Build the Docker image
docker build -t java-obfuscator .

# Run the container
docker run -p 8080:8080 java-obfuscator
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
