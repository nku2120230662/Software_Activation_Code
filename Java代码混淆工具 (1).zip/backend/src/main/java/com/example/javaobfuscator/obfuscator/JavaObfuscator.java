package com.example.javaobfuscator.obfuscator;

import com.example.javaobfuscator.dto.ObfuscationSettingsDto;
import com.example.javaobfuscator.exception.ObfuscationException;
import com.example.javaobfuscator.obfuscator.alternative.SimpleObfuscator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class JavaObfuscator {

    private final NameObfuscator nameObfuscator;
    private final StringEncryptor stringEncryptor;
    private final ControlFlowObfuscator controlFlowObfuscator;
    private final DebugInfoRemover debugInfoRemover;
    private final SimpleObfuscator simpleObfuscator;

    public JavaObfuscator(
            NameObfuscator nameObfuscator,
            StringEncryptor stringEncryptor,
            ControlFlowObfuscator controlFlowObfuscator,
            DebugInfoRemover debugInfoRemover,
            SimpleObfuscator simpleObfuscator) {
        this.nameObfuscator = nameObfuscator;
        this.stringEncryptor = stringEncryptor;
        this.controlFlowObfuscator = controlFlowObfuscator;
        this.debugInfoRemover = debugInfoRemover;
        this.simpleObfuscator = simpleObfuscator;
    }

    public void obfuscate(String inputFilePath, String outputFilePath, ObfuscationSettingsDto settings) {
        log.info("Starting obfuscation process for file: {}", inputFilePath);
        
        try {
            File inputFile = new File(inputFilePath);
            File outputFile = new File(outputFilePath);
            
            // Ensure output directory exists
            outputFile.getParentFile().mkdirs();
            
            // Get file extension
            String extension = FilenameUtils.getExtension(inputFilePath).toLowerCase();
            
            // Process based on file type
            switch (extension) {
                case "java":
                    obfuscateJavaSource(inputFile, outputFile, settings);
                    break;
                case "class":
                    obfuscateClassFile(inputFile, outputFile, settings);
                    break;
                case "jar":
                case "war":
                    obfuscateArchive(inputFile, outputFile, settings);
                    break;
                default:
                    throw new ObfuscationException("不支持的文件类型: " + extension, "仅支持 .java, .class, .jar 和 .war 文件");
            }
            
            log.info("Obfuscation completed successfully for file: {}", inputFilePath);
        } catch (Exception e) {
            log.error("Obfuscation failed: {}", e.getMessage(), e);
            throw new ObfuscationException("混淆处理失败: " + e.getMessage(), e);
        }
    }

    private void obfuscateJavaSource(File inputFile, File outputFile, ObfuscationSettingsDto settings) throws IOException {
        log.info("Obfuscating Java source file: {}", inputFile.getName());
        
        try {
            // 使用SimpleObfuscator处理Java源文件
            File obfuscatedFile = simpleObfuscator.obfuscateJavaSource(inputFile, settings);
            
            // 复制到输出文件
            Files.copy(obfuscatedFile.toPath(), outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            
            // 删除临时文件
            obfuscatedFile.delete();
            
            log.info("Java source file obfuscation completed successfully");
        } catch (Exception e) {
            log.error("Failed to obfuscate Java source file: {}", e.getMessage(), e);
            throw new ObfuscationException("Java源文件混淆失败: " + e.getMessage(), e);
        }
    }

    private void obfuscateClassFile(File inputFile, File outputFile, ObfuscationSettingsDto settings) throws IOException {
        // For demo purposes, we'll simulate class file obfuscation
        log.info("Obfuscating class file: {}", inputFile.getName());
        
        // Apply obfuscation techniques based on settings
        File tempFile = inputFile;
        
        if (settings.isRenameVariables() || settings.isRenameClasses()) {
            tempFile = nameObfuscator.obfuscate(tempFile, settings);
        }
        
        if (settings.isStringEncryption()) {
            tempFile = stringEncryptor.encrypt(tempFile, settings);
        }
        
        if (settings.isControlFlowObfuscation()) {
            tempFile = controlFlowObfuscator.obfuscate(tempFile, settings);
        }
        
        if (settings.isDebugProtection()) {
            tempFile = debugInfoRemover.removeDebugInfo(tempFile);
        }
        
        // Copy the final result to the output file
        Files.copy(tempFile.toPath(), outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    private void obfuscateArchive(File inputFile, File outputFile, ObfuscationSettingsDto settings) throws IOException {
        log.info("Obfuscating archive file: {}", inputFile.getName());
        
        try {
            // 使用SimpleObfuscator处理JAR/WAR文件
            File obfuscatedFile = simpleObfuscator.obfuscateJarFile(inputFile, settings);
            
            // 复制到输出文件
            Files.copy(obfuscatedFile.toPath(), outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            
            // 删除临时文件
            obfuscatedFile.delete();
            
            // 记录应用的混淆技术
            log.info("Applied the following obfuscation techniques:");
            if (settings.isRenameVariables()) log.info("- Variable renaming");
            if (settings.isRenameClasses()) log.info("- Class renaming");
            if (settings.isRenamePackages()) log.info("- Package renaming");
            if (settings.isControlFlowObfuscation()) log.info("- Control flow obfuscation");
            if (settings.isStringEncryption()) log.info("- String encryption");
            if (settings.isDeadCodeInsertion()) log.info("- Dead code insertion");
            if (settings.isDebugProtection()) log.info("- Debug protection");
            if (settings.isResourceEncryption()) log.info("- Resource encryption");
            
            // 记录保留的包和排除的类
            if (!settings.getPreservePackages().isEmpty()) {
                log.info("Preserved packages: {}", settings.getPreservePackages());
            }
            if (!settings.getExcludeClasses().isEmpty()) {
                log.info("Excluded classes: {}", settings.getExcludeClasses());
            }
            
            log.info("Archive file obfuscation completed successfully");
        } catch (Exception e) {
            log.error("Failed to obfuscate archive file: {}", e.getMessage(), e);
            throw new ObfuscationException("归档文件混淆失败: " + e.getMessage(), e);
        }
    }
}
