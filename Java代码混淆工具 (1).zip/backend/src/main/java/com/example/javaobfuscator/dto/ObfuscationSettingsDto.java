package com.example.javaobfuscator.dto;

import lombok.Data;

@Data
public class ObfuscationSettingsDto {
    private String obfuscationLevel = "medium";
    private boolean renameVariables = true;
    private boolean renameClasses = true;
    private boolean renamePackages = false;
    private boolean controlFlowObfuscation = true;
    private boolean stringEncryption = true;
    private boolean deadCodeInsertion = false;
    private boolean debugProtection = true;
    private boolean resourceEncryption = false;
    private String preservePackages = "";
    private String excludeClasses = "";
}
