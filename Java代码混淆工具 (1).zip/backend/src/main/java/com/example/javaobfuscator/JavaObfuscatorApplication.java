package com.example.javaobfuscator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.example.javaobfuscator.config.ObfuscatorProperties;

import jakarta.annotation.PostConstruct;
import java.io.File;

@SpringBootApplication
@EnableConfigurationProperties(ObfuscatorProperties.class)
@EnableScheduling
public class JavaObfuscatorApplication {

    private final ObfuscatorProperties properties;

    public JavaObfuscatorApplication(ObfuscatorProperties properties) {
        this.properties = properties;
    }

    public static void main(String[] args) {
        SpringApplication.run(JavaObfuscatorApplication.class, args);
    }

    @PostConstruct
    public void init() {
        // Create necessary directories
        createDirectoryIfNotExists(properties.getTempDir());
        createDirectoryIfNotExists(properties.getOutputDir());
    }

    private void createDirectoryIfNotExists(String path) {
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }
}
