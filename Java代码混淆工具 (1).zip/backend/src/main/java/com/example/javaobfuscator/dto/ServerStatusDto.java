package com.example.javaobfuscator.dto;

import lombok.Data;

@Data
public class ServerStatusDto {
    private String status;
    private String version;
    private String uptime;
    private String memoryUsage;
}
