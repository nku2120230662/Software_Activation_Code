package com.example.javaobfuscator.service;

import com.example.javaobfuscator.config.ObfuscatorProperties;
import com.example.javaobfuscator.dto.ObfuscationOptionsDto;
import com.example.javaobfuscator.dto.ObfuscationSettingsDto;
import com.example.javaobfuscator.exception.InvalidFileException;
import com.example.javaobfuscator.exception.ObfuscationException;
import com.example.javaobfuscator.obfuscator.JavaObfuscator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class ObfuscatorService {

    private final ObfuscatorProperties properties;
    private final JavaObfuscator javaObfuscator;
    private final TempFileService tempFileService;

    public ObfuscatorService(ObfuscatorProperties properties, JavaObfuscator javaObfuscator, TempFileService tempFileService) {
        this.properties = properties;
        this.javaObfuscator = javaObfuscator;
        this.tempFileService = tempFileService;
    }

    public ObfuscationOptionsDto getAvailableOptions() {
        ObfuscationOptionsDto options = new ObfuscationOptionsDto();
        
        // Set available obfuscation levels
        options.setObfuscationLevels(new String[]{"low", "medium", "high"});
        
        // Set available features
        Map<String, Boolean> features = new HashMap<>();
        features.put("renameVariables", true);
        features.put("renameClasses", true);
        features.put("renamePackages", true);
        features.put("controlFlowObfuscation", true);
        features.put("stringEncryption", true);
        features.put("deadCodeInsertion", true);
        features.put("debugProtection", true);
        features.put("resourceEncryption", true);
        options.setFeatures(features);
        
        // Set max file size
        options.setMaxFileSize(10 * 1024 * 1024); // 10MB
        
        return options;
    }

    public boolean isValidFileType(MultipartFile file) {
        if (file.isEmpty()) {
            throw new InvalidFileException("文件为空");
        }
        
        String filename = file.getOriginalFilename();
        if (filename == null || filename.isEmpty()) {
            throw new InvalidFileException("文件名无效");
        }
        
        String extension = FilenameUtils.getExtension(filename).toLowerCase();
        if (!Arrays.asList("java", "jar", "war", "class").contains(extension)) {
            throw new InvalidFileException("不支持的文件类型: " + extension + "。请上传 .java, .jar, .war 或 .class 文件");
        }
        
        return true;
    }

    public Resource obfuscate(MultipartFile file, ObfuscationSettingsDto settings) throws IOException {
        // Generate unique IDs for input and output files
        String sessionId = UUID.randomUUID().toString();
        String inputFileName = sessionId + "_" + file.getOriginalFilename();
        String outputFileName = "obfuscated_" + sessionId + "_" + file.getOriginalFilename();
        
        // Create paths for input and output files
        Path inputPath = Paths.get(properties.getTempDir(), inputFileName);
        Path outputPath = Paths.get(properties.getOutputDir(), outputFileName);
        
        try {
            // Save the uploaded file
            Files.copy(file.getInputStream(), inputPath);
            
            // Perform obfuscation
            javaObfuscator.obfuscate(inputPath.toString(), outputPath.toString(), settings);
            
            // Return the obfuscated file as a resource
            File outputFile = outputPath.toFile();
            if (!outputFile.exists()) {
                throw new ObfuscationException("混淆处理失败", "输出文件未生成");
            }
            
            // Register the file for cleanup
            tempFileService.registerForCleanup(inputPath.toFile());
            tempFileService.registerForCleanup(outputFile);
            
            return new FileSystemResource(outputFile);
        } catch (Exception e) {
            // Clean up any temporary files
            try {
                Files.deleteIfExists(inputPath);
                Files.deleteIfExists(outputPath);
            } catch (IOException ex) {
                log.error("Failed to clean up temporary files", ex);
            }
            
            throw new ObfuscationException("混淆处理失败: " + e.getMessage(), e);
        }
    }
}
