package com.example.javaobfuscator.dto;

import lombok.Data;

import java.util.Map;

@Data
public class ObfuscationOptionsDto {
    private String[] obfuscationLevels;
    private Map<String, Boolean> features;
    private long maxFileSize;
}
