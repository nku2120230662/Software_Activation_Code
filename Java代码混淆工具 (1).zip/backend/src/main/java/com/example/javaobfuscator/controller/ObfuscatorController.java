package com.example.javaobfuscator.controller;

import com.example.javaobfuscator.dto.ObfuscationOptionsDto;
import com.example.javaobfuscator.dto.ObfuscationSettingsDto;
import com.example.javaobfuscator.dto.ServerStatusDto;
import com.example.javaobfuscator.service.ObfuscatorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.time.Duration;
import java.time.Instant;

@RestController
@Slf4j
public class ObfuscatorController {

    private final ObfuscatorService obfuscatorService;
    private final Instant startTime = Instant.now();

    public ObfuscatorController(ObfuscatorService obfuscatorService) {
        this.obfuscatorService = obfuscatorService;
    }

    @GetMapping("/status")
    public ResponseEntity<ServerStatusDto> getStatus() {
        long uptime = Duration.between(startTime, Instant.now()).getSeconds();
        long hours = uptime / 3600;
        long minutes = (uptime % 3600) / 60;
        
        long memoryUsage = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed() / (1024 * 1024);
        
        ServerStatusDto status = new ServerStatusDto();
        status.setStatus("running");
        status.setVersion("1.0.0");
        status.setUptime(hours + "h " + minutes + "m");
        status.setMemoryUsage(memoryUsage + "MB");
        
        return ResponseEntity.ok(status);
    }

    @GetMapping("/options")
    public ResponseEntity<ObfuscationOptionsDto> getOptions() {
        ObfuscationOptionsDto options = obfuscatorService.getAvailableOptions();
        return ResponseEntity.ok(options);
    }

    @PostMapping("/obfuscate")
    public ResponseEntity<Resource> obfuscateCode(
            @RequestParam("file") MultipartFile file,
            @ModelAttribute @Valid ObfuscationSettingsDto settings) throws IOException {
        
        log.info("Received obfuscation request for file: {}, size: {}", 
                file.getOriginalFilename(), file.getSize());
        
        // Validate file type
        if (!obfuscatorService.isValidFileType(file)) {
            return ResponseEntity.badRequest().build();
        }
        
        // Process the file
        Resource obfuscatedFile = obfuscatorService.obfuscate(file, settings);
        
        // Prepare the response
        String filename = "obfuscated_" + file.getOriginalFilename();
        
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(obfuscatedFile);
    }
}
