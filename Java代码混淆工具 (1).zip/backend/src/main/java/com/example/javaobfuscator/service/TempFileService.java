package com.example.javaobfuscator.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class TempFileService {

    // Map to store files and their creation time
    private final Map<File, Instant> tempFiles = new ConcurrentHashMap<>();

    /**
     * Register a file for cleanup after processing
     */
    public void registerForCleanup(File file) {
        tempFiles.put(file, Instant.now());
        log.debug("Registered file for cleanup: {}", file.getAbsolutePath());
    }

    /**
     * Scheduled task to clean up temporary files older than 1 hour
     */
    @Scheduled(fixedRate = 3600000) // Run every hour
    public void cleanupTempFiles() {
        log.info("Running temporary file cleanup task");
        Instant now = Instant.now();
        
        tempFiles.entrySet().removeIf(entry -> {
            File file = entry.getKey();
            Instant creationTime = entry.getValue();
            
            // Check if file is older than 1 hour
            if (now.minusSeconds(3600).isAfter(creationTime)) {
                if (file.exists() && file.delete()) {
                    log.info("Deleted temporary file: {}", file.getAbsolutePath());
                    return true;
                } else {
                    log.warn("Failed to delete temporary file: {}", file.getAbsolutePath());
                }
            }
            return false;
        });
    }
}
