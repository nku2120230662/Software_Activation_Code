package com.example.javaobfuscator.exception;

import lombok.Getter;

@Getter
public class ObfuscationException extends RuntimeException {
    
    private final String details;
    
    public ObfuscationException(String message, String details) {
        super(message);
        this.details = details;
    }
    
    public ObfuscationException(String message, Throwable cause) {
        super(message, cause);
        this.details = cause.getMessage();
    }
}
