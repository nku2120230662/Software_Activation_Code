package com.example.javaobfuscator.obfuscator.alternative;

import com.example.javaobfuscator.dto.ObfuscationSettingsDto;
import com.example.javaobfuscator.exception.ObfuscationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;

/**
 * 简单的Java代码混淆器实现，不依赖ProGuard
 * 用于在ProGuard不可用时提供基本的混淆功能
 */
@Component
@Slf4j
public class SimpleObfuscator {

    // 用于生成随机标识符的字符
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final String ALPHABET_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGITS = "0123456789";
    
    // 用于标识符替换的映射
    private final Map<String, String> identifierMap = new HashMap<>();
    
    // 随机数生成器
    private final Random random = new Random();

    /**
     * 混淆Java源代码文件
     */
    public File obfuscateJavaSource(File inputFile, ObfuscationSettingsDto settings) throws IOException {
        log.info("使用简单混淆器处理Java源文件: {}", inputFile.getName());
        
        // 读取源文件内容
        String content = FileUtils.readFileToString(inputFile, StandardCharsets.UTF_8);
        
        // 应用混淆技术
        if (settings.isRenameVariables()) {
            content = obfuscateVariableNames(content);
        }
        
        if (settings.isStringEncryption()) {
            content = encryptStrings(content);
        }
        
        if (settings.isControlFlowObfuscation()) {
            content = obfuscateControlFlow(content);
        }
        
        if (settings.isDeadCodeInsertion()) {
            content = insertDeadCode(content);
        }
        
        // 创建输出文件
        File outputFile = File.createTempFile("obfuscated_", ".java");
        FileUtils.writeStringToFile(outputFile, content, StandardCharsets.UTF_8);
        
        return outputFile;
    }

    /**
     * 混淆JAR文件
     */
    public File obfuscateJarFile(File inputFile, ObfuscationSettingsDto settings) throws IOException {
        log.info("使用简单混淆器处理JAR文件: {}", inputFile.getName());
        
        // 创建临时目录解压JAR文件
        Path tempDir = Files.createTempDirectory("jar_extract_");
        
        // 创建输出JAR文件
        File outputFile = File.createTempFile("obfuscated_", ".jar");
        
        try (JarFile jarFile = new JarFile(inputFile);
             JarOutputStream jarOutputStream = new JarOutputStream(new FileOutputStream(outputFile))) {
            
            // 处理JAR文件中的每个条目
            Enumeration<JarEntry> entries = jarFile.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String entryName = entry.getName();
                
                // 读取条目内容
                InputStream inputStream = jarFile.getInputStream(entry);
                byte[] buffer = inputStream.readAllBytes();
                
                // 如果是class文件，进行混淆处理
                if (entryName.endsWith(".class")) {
                    // 在实际实现中，这里应该使用ASM或Javassist处理class文件
                    // 这里我们只是简单地复制原始文件
                    log.debug("跳过class文件混淆: {}", entryName);
                } 
                // 如果是Java源文件，进行混淆处理
                else if (entryName.endsWith(".java")) {
                    // 将内容写入临时文件
                    File tempFile = new File(tempDir.toFile(), FilenameUtils.getName(entryName));
                    FileUtils.writeByteArrayToFile(tempFile, buffer);
                    
                    // 混淆源文件
                    File obfuscatedFile = obfuscateJavaSource(tempFile, settings);
                    buffer = FileUtils.readFileToByteArray(obfuscatedFile);
                    
                    // 删除临时文件
                    obfuscatedFile.delete();
                }
                
                // 将处理后的内容写入输出JAR
                JarEntry newEntry = new JarEntry(entryName);
                jarOutputStream.putNextEntry(newEntry);
                jarOutputStream.write(buffer);
                jarOutputStream.closeEntry();
            }
        } catch (Exception e) {
            throw new ObfuscationException("JAR文件混淆失败: " + e.getMessage(), e);
        } finally {
            // 清理临时目录
            FileUtils.deleteDirectory(tempDir.toFile());
        }
        
        return outputFile;
    }

    /**
     * 混淆变量名
     */
    private String obfuscateVariableNames(String content) {
        // 查找变量声明
        Pattern pattern = Pattern.compile("\\b(int|float|double|long|boolean|char|String|\\w+)\\s+(\\w+)\\s*[=;]");
        Matcher matcher = pattern.matcher(content);
        
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String type = matcher.group(1);
            String varName = matcher.group(2);
            
            // 跳过Java关键字和常见的循环变量
            if (isJavaKeyword(varName) || varName.equals("i") || varName.equals("j") || varName.equals("k")) {
                continue;
            }
            
            // 为变量名生成替代名称
            String obfuscatedName = identifierMap.computeIfAbsent(varName, k -> generateRandomIdentifier());
            
            // 替换变量名
            matcher.appendReplacement(result, type + " " + obfuscatedName + (matcher.group().endsWith("=") ? "=" : ";"));
        }
        matcher.appendTail(result);
        
        // 替换变量使用
        String obfuscated = result.toString();
        for (Map.Entry<String, String> entry : identifierMap.entrySet()) {
            String original = entry.getKey();
            String replacement = entry.getValue();
            
            // 使用单词边界确保只替换完整的标识符
            obfuscated = obfuscated.replaceAll("\\b" + original + "\\b", replacement);
        }
        
        return obfuscated;
    }

    /**
     * 加密字符串常量
     */
    private String encryptStrings(String content) {
        // 查找字符串字面量
        Pattern pattern = Pattern.compile("\"([^\"]*)\"");
        Matcher matcher = pattern.matcher(content);
        
        StringBuffer result = new StringBuffer();
        boolean methodAdded = false;
        
        while (matcher.find()) {
            String str = matcher.group(1);
            
            // 跳过空字符串
            if (str.isEmpty()) {
                continue;
            }
            
            // 加密字符串
            String encrypted = encryptString(str);
            
            // 替换为解密调用
            matcher.appendReplacement(result, "decrypt(\"" + encrypted + "\")");
            methodAdded = true;
        }
        matcher.appendTail(result);
        
        // 如果有字符串被加密，添加解密方法
        if (methodAdded) {
            result.append("\n\n// 由混淆器添加的解密方法\n");
            result.append("private static String decrypt(String s) {\n");
            result.append("    StringBuilder result = new StringBuilder();\n");
            result.append("    for (int i = 0; i < s.length(); i++) {\n");
            result.append("        result.append((char) (s.charAt(i) ^ 42));\n");
            result.append("    }\n");
            result.append("    return result.toString();\n");
            result.append("}\n");
        }
        
        return result.toString();
    }

    /**
     * 简单的字符串加密
     */
    private String encryptString(String input) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : input.toCharArray()) {
            encrypted.append((char) (c ^ 42)); // 简单的XOR加密
        }
        return encrypted.toString();
    }

    /**
     * 混淆控制流
     */
    private String obfuscateControlFlow(String content) {
        // 查找if语句
        Pattern pattern = Pattern.compile("if\\s*\\((.+?)\\)\\s*\\{([^}]*)}");
        Matcher matcher = pattern.matcher(content);
        
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String condition = matcher.group(1);
            String body = matcher.group(2);
            
            // 添加不影响结果的复杂条件
            String obfuscatedCondition = "(" + condition + " && (1 < 2 || Math.random() < 0.999))";
            
            // 替换为混淆后的if语句
            matcher.appendReplacement(result, "if (" + obfuscatedCondition + ") {" + body + "}");
        }
        matcher.appendTail(result);
        
        return result.toString();
    }

    /**
     * 插入无效代码
     */
    private String insertDeadCode(String content) {
        // 查找方法体
        Pattern pattern = Pattern.compile("\\{([^{}]*)\\}");
        Matcher matcher = pattern.matcher(content);
        
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String methodBody = matcher.group(1);
            
            // 插入无效代码
            String deadCode = "\n        // 无效代码\n" +
                              "        if (false) {\n" +
                              "            System.out.println(\"This code will never execute\");\n" +
                              "            int x = 10;\n" +
                              "            while (x > 0 && false) {\n" +
                              "                x--;\n" +
                              "            }\n" +
                              "        }\n";
            
            // 替换方法体
            matcher.appendReplacement(result, "{" + methodBody + deadCode + "}");
        }
        matcher.appendTail(result);
        
        return result.toString();
    }

    /**
     * 生成随机标识符
     */
    private String generateRandomIdentifier() {
        StringBuilder sb = new StringBuilder();
        
        // 第一个字符必须是字母
        sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
        
        // 生成剩余字符
        int length = 3 + random.nextInt(5); // 长度在3-7之间
        for (int i = 1; i < length; i++) {
            String chars = ALPHABET + ALPHABET_CAPS + DIGITS;
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        
        return "obf_" + sb.toString();
    }

    /**
     * 检查是否是Java关键字
     */
    private boolean isJavaKeyword(String word) {
        Set<String> keywords = Set.of(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
            "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
            "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
            "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super",
            "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void", "volatile", "while"
        );
        return keywords.contains(word);
    }
}
