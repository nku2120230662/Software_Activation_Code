package com.example.javaobfuscator.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "obfuscator")
public class ObfuscatorProperties {
    
    private String tempDir;
    private String outputDir;
    private String defaultLevel;
    private Cors cors = new Cors();
    
    @Data
    public static class Cors {
        private String[] allowedOrigins;
        private String[] allowedMethods;
        private String[] allowedHeaders;
        private boolean allowCredentials;
        private long maxAge;
    }
}
