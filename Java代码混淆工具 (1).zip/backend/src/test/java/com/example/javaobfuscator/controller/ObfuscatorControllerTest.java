package com.example.javaobfuscator.controller;

import com.example.javaobfuscator.dto.ObfuscationOptionsDto;
import com.example.javaobfuscator.dto.ServerStatusDto;
import com.example.javaobfuscator.service.ObfuscatorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ObfuscatorController.class)
public class ObfuscatorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ObfuscatorService obfuscatorService;

    @Test
    public void testGetStatus() throws Exception {
        mockMvc.perform(get("/status")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("running"))
                .andExpect(jsonPath("$.version").exists())
                .andExpect(jsonPath("$.uptime").exists())
                .andExpect(jsonPath("$.memoryUsage").exists());
    }

    @Test
    public void testGetOptions() throws Exception {
        // Prepare mock data
        ObfuscationOptionsDto options = new ObfuscationOptionsDto();
        options.setObfuscationLevels(new String[]{"low", "medium", "high"});
        
        Map<String, Boolean> features = new HashMap<>();
        features.put("renameVariables", true);
        features.put("renameClasses", true);
        options.setFeatures(features);
        
        options.setMaxFileSize(10485760L);
        
        // Configure mock
        when(obfuscatorService.getAvailableOptions()).thenReturn(options);
        
        // Perform test
        mockMvc.perform(get("/options")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.obfuscationLevels").isArray())
                .andExpect(jsonPath("$.obfuscationLevels[0]").value("low"))
                .andExpect(jsonPath("$.features.renameVariables").value(true))
                .andExpect(jsonPath("$.maxFileSize").value(10485760));
    }
}
