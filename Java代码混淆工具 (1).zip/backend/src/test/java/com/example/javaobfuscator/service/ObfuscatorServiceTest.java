package com.example.javaobfuscator.service;

import com.example.javaobfuscator.config.ObfuscatorProperties;
import com.example.javaobfuscator.dto.ObfuscationOptionsDto;
import com.example.javaobfuscator.dto.ObfuscationSettingsDto;
import com.example.javaobfuscator.exception.InvalidFileException;
import com.example.javaobfuscator.obfuscator.JavaObfuscator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ObfuscatorServiceTest {

    @Mock
    private ObfuscatorProperties properties;

    @Mock
    private JavaObfuscator javaObfuscator;

    @Mock
    private TempFileService tempFileService;

    @InjectMocks
    private ObfuscatorService obfuscatorService;

    @BeforeEach
    void setUp() {
        when(properties.getTempDir()).thenReturn("./temp");
        when(properties.getOutputDir()).thenReturn("./output");
    }

    @Test
    void testGetAvailableOptions() {
        ObfuscationOptionsDto options = obfuscatorService.getAvailableOptions();
        
        assertNotNull(options);
        assertNotNull(options.getObfuscationLevels());
        assertTrue(options.getObfuscationLevels().length > 0);
        assertNotNull(options.getFeatures());
        assertTrue(options.getFeatures().size() > 0);
        assertTrue(options.getMaxFileSize() > 0);
    }

    @Test
    void testIsValidFileType_ValidJavaFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test.java",
                "text/plain",
                "class Test {}".getBytes()
        );
        
        assertTrue(obfuscatorService.isValidFileType(file));
    }

    @Test
    void testIsValidFileType_ValidJarFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test.jar",
                "application/java-archive",
                "dummy content".getBytes()
        );
        
        assertTrue(obfuscatorService.isValidFileType(file));
    }

    @Test
    void testIsValidFileType_InvalidFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test.txt",
                "text/plain",
                "dummy content".getBytes()
        );
        
        assertThrows(InvalidFileException.class, () -> obfuscatorService.isValidFileType(file));
    }

    @Test
    void testIsValidFileType_EmptyFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test.java",
                "text/plain",
                new byte[0]
        );
        
        assertThrows(InvalidFileException.class, () -> obfuscatorService.isValidFileType(file));
    }
}
