#!/bin/bash

# 检查Java版本
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "检测到Java版本: $java_version"

# 检查是否已构建
if [ ! -f "target/java-obfuscator-0.0.1-SNAPSHOT.jar" ]; then
    echo "JAR文件不存在，正在构建项目..."
    ./build.sh
fi

# 创建必要的目录
mkdir -p temp output

# 运行应用
echo "正在启动Java混淆器后端..."
java -jar target/java-obfuscator-0.0.1-SNAPSHOT.jar
