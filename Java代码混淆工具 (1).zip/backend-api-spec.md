# Java混淆器后端API规范

本文档定义了Java混淆器前端与Spring Boot后端之间的API接口规范。

## 基础URL

所有API请求都应该发送到以下基础URL：

```
http://localhost:8080/api
```

## 认证

目前API不需要认证。如果将来需要添加认证，将使用JWT令牌或基本认证。

## API端点

### 1. 服务器状态

**请求**：
- 方法：GET
- 路径：`/status`

**响应**：
```json
{
  "status": "running",
  "version": "1.0.0",
  "uptime": "10h 30m",
  "memoryUsage": "256MB"
}
```

### 2. 获取混淆选项

**请求**：
- 方法：GET
- 路径：`/options`

**响应**：
```json
{
  "obfuscationLevels": ["low", "medium", "high"],
  "features": {
    "renameVariables": true,
    "renameClasses": true,
    "renamePackages": true,
    "controlFlowObfuscation": true,
    "stringEncryption": true,
    "deadCodeInsertion": true,
    "debugProtection": true,
    "resourceEncryption": true
  },
  "maxFileSize": 10485760
}
```

### 3. 上传并混淆代码

**请求**：
- 方法：POST
- 路径：`/obfuscate`
- 内容类型：`multipart/form-data`
- 参数：
  - `file`：要混淆的Java文件（必需）
  - `obfuscationLevel`：混淆级别（可选，默认为"medium"）
  - `renameVariables`：是否混淆变量名（可选，布尔值）
  - `renameClasses`：是否混淆类名（可选，布尔值）
  - `renamePackages`：是否混淆包名（可选，布尔值）
  - `controlFlowObfuscation`：是否进行控制流混淆（可选，布尔值）
  - `stringEncryption`：是否加密字符串（可选，布尔值）
  - `deadCodeInsertion`：是否插入无效代码（可选，布尔值）
  - `debugProtection`：是否添加调试保护（可选，布尔值）
  - `resourceEncryption`：是否加密资源（可选，布尔值）
  - `preservePackages`：保留的包名列表（可选，逗号分隔的字符串）
  - `excludeClasses`：排除的类名列表（可选，逗号分隔的字符串）

**成功响应**：
- 状态码：200 OK
- 内容类型：`application/octet-stream`
- 内容：混淆后的文件（二进制数据）
- 头部：
  - `Content-Disposition: attachment; filename="obfuscated_filename.jar"`

**错误响应**：
- 状态码：400 Bad Request / 500 Internal Server Error
- 内容类型：`application/json`
- 内容：
```json
{
  "status": "error",
  "message": "错误描述",
  "details": "详细错误信息"
}
```

## 错误代码

| 状态码 | 错误代码 | 描述 |
|--------|----------|------|
| 400 | INVALID_FILE | 无效的文件类型 |
| 400 | FILE_TOO_LARGE | 文件大小超过限制 |
| 400 | INVALID_PARAMETER | 无效的参数值 |
| 500 | OBFUSCATION_FAILED | 混淆处理失败 |
| 500 | SERVER_ERROR | 服务器内部错误 |

## 后端实现建议

### 技术栈

- Spring Boot 2.7+
- Java 11+
- ASM/Javassist 用于字节码操作
- ProGuard/Yguard 作为基础混淆引擎

### 核心组件

1. **文件上传服务**：处理文件上传和验证
2. **混淆引擎**：实现各种混淆技术
3. **字节码处理器**：修改和转换Java字节码
4. **加壳服务**：为应用程序添加保护层

### 安全考虑

1. 限制上传文件大小
2. 验证文件类型
3. 扫描上传文件中的恶意代码
4. 使用临时目录处理文件，并在处理完成后删除
5. 实现速率限制，防止DoS攻击

## 部署建议

1. 使用Docker容器化应用
2. 配置适当的内存限制
3. 使用负载均衡器处理高并发请求
4. 实现健康检查和监控
5. 配置HTTPS以保护数据传输
