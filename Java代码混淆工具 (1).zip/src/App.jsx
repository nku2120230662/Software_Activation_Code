import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import ObfuscationTool from './pages/ObfuscationTool';
import Documentation from './pages/Documentation';
import About from './pages/About';
import ErrorBoundary from './components/common/ErrorBoundary';
import LoadingSpinner from './components/common/LoadingSpinner';
import { getServerStatus } from './services/api';
import './styles/App.css';

const App = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [serverConnected, setServerConnected] = useState(false);

  useEffect(() => {
    // 检查后端服务器连接状态
    const checkServerStatus = async () => {
      try {
        const response = await getServerStatus();
        console.log('Server status response:', response);
        setServerConnected(response.data.status === 'running');
      } catch (error) {
        console.error('Server connection failed:', error);
        setServerConnected(false);
      } finally {
        // 无论成功失败，都结束加载状态
        setIsLoading(false);
      }
    };

    // 页面加载时检查服务器状态
    checkServerStatus();
  }, []);

  if (isLoading) {
    return (
      <div className="loading-container">
        <LoadingSpinner size="large" text="正在连接服务器..." />
      </div>
    );
  }

  return (
    <div className="app">
      <Header serverConnected={serverConnected} />
      <main className="main-content">
        <ErrorBoundary>
          <Routes>
            <Route path="/" element={<Home serverConnected={serverConnected} />} />
            <Route path="/tool" element={<ObfuscationTool />} />
            <Route path="/docs" element={<Documentation />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
};

export default App;
