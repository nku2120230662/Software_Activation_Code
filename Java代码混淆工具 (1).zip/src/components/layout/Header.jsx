import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Header.css';

const Header = ({ serverConnected = false }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <header className="header">
      <div className="container header-container">
        <div className="logo-container">
          <Link to="/" className="logo">
            <i className="fas fa-shield-alt"></i>
            <span>Java混淆器</span>
          </Link>
          <div className={`server-status ${serverConnected ? 'connected' : 'disconnected'}`}>
            <i className={`fas ${serverConnected ? 'fa-circle' : 'fa-exclamation-circle'}`}></i>
            <span>{serverConnected ? '服务器已连接' : '服务器未连接'}</span>
          </div>
        </div>
        
        <button className="mobile-menu-btn" onClick={toggleMenu}>
          <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
        
        <nav className={`nav-menu ${menuOpen ? 'open' : ''}`}>
          <ul className="nav-list">
            <li className="nav-item">
              <Link to="/" className={`nav-link ${isActive('/')}`} onClick={() => setMenuOpen(false)}>
                首页
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/tool" className={`nav-link ${isActive('/tool')}`} onClick={() => setMenuOpen(false)}>
                混淆工具
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/docs" className={`nav-link ${isActive('/docs')}`} onClick={() => setMenuOpen(false)}>
                文档
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/about" className={`nav-link ${isActive('/about')}`} onClick={() => setMenuOpen(false)}>
                关于
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
