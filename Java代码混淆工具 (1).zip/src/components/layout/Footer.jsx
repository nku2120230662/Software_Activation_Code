import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container footer-container">
        <div className="footer-section">
          <h3 className="footer-title">Java混淆器</h3>
          <p className="footer-description">
            专业的Java代码混淆和加壳工具，保护您的知识产权和软件安全。
          </p>
          <div className="social-links">
            <a href="#" className="social-link">
              <i className="fab fa-github"></i>
            </a>
            <a href="#" className="social-link">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="social-link">
              <i className="fab fa-linkedin"></i>
            </a>
          </div>
        </div>

        <div className="footer-section">
          <h3 className="footer-title">快速链接</h3>
          <ul className="footer-links">
            <li><Link to="/">首页</Link></li>
            <li><Link to="/tool">混淆工具</Link></li>
            <li><Link to="/docs">文档</Link></li>
            <li><Link to="/about">关于我们</Link></li>
          </ul>
        </div>

        <div className="footer-section">
          <h3 className="footer-title">联系我们</h3>
          <ul className="contact-info">
            <li>
              <i className="fas fa-envelope"></i>
              <a href="mailto:contact@javaobfuscator.com">contact@javaobfuscator.com</a>
            </li>
            <li>
              <i className="fas fa-phone"></i>
              <span>+86 123 4567 8910</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="copyright">
        <div className="container">
          <p>&copy; {currentYear} Java混淆器. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
