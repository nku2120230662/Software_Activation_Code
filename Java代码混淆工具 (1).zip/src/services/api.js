import axios from 'axios';
import apiConfig from '../config/apiConfig';

// 创建axios实例
const api = axios.create({
  baseURL: apiConfig.baseUrl,
  timeout: apiConfig.timeout,
  headers: apiConfig.headers,
  withCredentials: true
});

// 请求拦截器
api.interceptors.request.use(
  config => {
    console.log('API Request:', config.url);
    return config;
  },
  error => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// 响应拦截器
api.interceptors.response.use(
  response => {
    console.log('API Response:', response.status);
    return response;
  },
  error => {
    // 处理错误响应
    if (error.response) {
      // 服务器返回错误
      console.error('API Error:', error.response.data);
    } else if (error.request) {
      // 请求发送但没有收到响应
      console.error('Network Error:', error.request);
    } else {
      // 请求设置出错
      console.error('Request Error:', error.message);
    }
    return Promise.reject(error);
  }
);

// 上传文件并进行混淆
export const obfuscateCode = async (file, settings) => {
  const formData = new FormData();
  formData.append('file', file);
  
  // 添加所有设置到formData
  Object.keys(settings).forEach(key => {
    formData.append(key, settings[key]);
  });
  
  return api.post('/obfuscate', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    responseType: 'blob' // 设置响应类型为blob，用于文件下载
  });
};

// 获取混淆选项配置
export const getObfuscationOptions = async () => {
  return api.get('/options');
};

// 获取服务器状态
export const getServerStatus = async () => {
  try {
    console.log('Checking server status...');
    const response = await api.get('/status');
    console.log('Server status:', response.data);
    return response;
  } catch (error) {
    console.error('Server status check failed:', error);
    throw error;
  }
};

export default api;
