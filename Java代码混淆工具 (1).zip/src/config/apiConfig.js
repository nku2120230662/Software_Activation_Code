/**
 * API配置文件
 * 定义API基础URL和其他API相关配置
 */

// 获取API基础URL
export const getApiBaseUrl = () => {
  // 检查是否有全局定义的API URL
  if (typeof window !== 'undefined' && window.REACT_APP_API_URL) {
    return window.REACT_APP_API_URL;
  }
  // 默认使用本地开发服务器地址
  return 'http://localhost:8080/api';
};

// API超时时间（毫秒）
export const API_TIMEOUT = 60000;

// API请求头
export const API_HEADERS = {
  'Content-Type': 'application/json'
};

// 导出默认配置
export default {
  baseUrl: getApiBaseUrl(),
  timeout: API_TIMEOUT,
  headers: API_HEADERS
};
