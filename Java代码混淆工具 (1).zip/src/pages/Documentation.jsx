import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { docco } from 'react-syntax-highlighter/dist/esm/styles/hljs';
import './Documentation.css';

const Documentation = () => {
  const [activeTab, setActiveTab] = useState('getting-started');

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="documentation">
      <div className="container">
        <h1 className="page-title">文档中心</h1>
        <p className="page-description">
          了解如何使用Java混淆器保护您的代码
        </p>
        
        <div className="docs-container">
          <div className="docs-sidebar">
            <ul className="docs-nav">
              <li 
                className={activeTab === 'getting-started' ? 'active' : ''}
                onClick={() => handleTabClick('getting-started')}
              >
                <i className="fas fa-play-circle"></i> 快速开始
              </li>
              <li 
                className={activeTab === 'features' ? 'active' : ''}
                onClick={() => handleTabClick('features')}
              >
                <i className="fas fa-list-ul"></i> 功能介绍
              </li>
              <li 
                className={activeTab === 'usage' ? 'active' : ''}
                onClick={() => handleTabClick('usage')}
              >
                <i className="fas fa-book"></i> 使用指南
              </li>
              <li 
                className={activeTab === 'api' ? 'active' : ''}
                onClick={() => handleTabClick('api')}
              >
                <i className="fas fa-code"></i> API文档
              </li>
              <li 
                className={activeTab === 'examples' ? 'active' : ''}
                onClick={() => handleTabClick('examples')}
              >
                <i className="fas fa-file-code"></i> 示例代码
              </li>
              <li 
                className={activeTab === 'faq' ? 'active' : ''}
                onClick={() => handleTabClick('faq')}
              >
                <i className="fas fa-question-circle"></i> 常见问题
              </li>
            </ul>
          </div>
          
          <div className="docs-content">
            {activeTab === 'getting-started' && (
              <div className="docs-section">
                <h2 className="docs-title">快速开始</h2>
                <p>Java混淆器是一个强大的代码保护工具，可以帮助您防止代码被逆向工程和盗版。本指南将帮助您快速上手使用。</p>
                
                <h3 className="docs-subtitle">安装</h3>
                <p>您可以通过以下方式使用Java混淆器：</p>
                <ul>
                  <li>使用在线工具（推荐）：直接在我们的<Link to="/tool">在线平台</Link>上传并处理您的代码</li>
                  <li>下载独立版本：从我们的GitHub仓库下载最新版本</li>
                  <li>使用Maven插件：将我们的插件集成到您的构建过程中</li>
                </ul>
                
                <h3 className="docs-subtitle">基本用法</h3>
                <p>使用Java混淆器的基本步骤如下：</p>
                <ol>
                  <li>上传您的Java源代码或编译后的JAR/WAR文件</li>
                  <li>配置混淆选项，如名称混淆、控制流混淆、字符串加密等</li>
                  <li>点击"开始混淆"按钮处理您的代码</li>
                  <li>下载混淆后的代码并在您的项目中使用</li>
                </ol>
                
                <div className="note">
                  <i className="fas fa-info-circle"></i>
                  <p>注意：混淆后的代码在功能上与原始代码完全相同，但会更难以理解和逆向工程。</p>
                </div>
                
                <h3 className="docs-subtitle">下一步</h3>
                <p>要了解更多关于Java混淆器的功能和高级用法，请查看以下资源：</p>
                <ul>
                  <li><span className="link" onClick={() => handleTabClick('features')}>功能介绍</span> - 了解所有可用的混淆和保护技术</li>
                  <li><span className="link" onClick={() => handleTabClick('usage')}>使用指南</span> - 详细了解如何配置和使用混淆器</li>
                  <li><span className="link" onClick={() => handleTabClick('examples')}>示例代码</span> - 查看混淆前后的代码对比</li>
                </ul>
              </div>
            )}
            
            {activeTab === 'features' && (
              <div className="docs-section">
                <h2 className="docs-title">功能介绍</h2>
                <p>Java混淆器提供多种代码保护技术，可以根据您的需求进行组合使用。以下是主要功能的详细介绍：</p>
                
                <div className="feature-item">
                  <h3 className="feature-title">名称混淆</h3>
                  <p>将类、方法、字段和变量的名称替换为无意义的标识符，使代码难以理解。</p>
                  <ul>
                    <li><strong>类名混淆</strong>：将有意义的类名替换为随机字符</li>
                    <li><strong>方法名混淆</strong>：混淆所有非公共API的方法名</li>
                    <li><strong>变量名混淆</strong>：替换局部变量和参数名</li>
                    <li><strong>包名混淆</strong>：重组和混淆包结构</li>
                  </ul>
                </div>
                
                <div className="feature-item">
                  <h3 className="feature-title">控制流混淆</h3>
                  <p>修改程序的执行流程，增加代码复杂度，阻碍静态分析和理解。</p>
                  <ul>
                    <li><strong>控制流平坦化</strong>：将顺序代码转换为基于状态机的结构</li>
                    <li><strong>虚假条件</strong>：插入永远为真或永远为假的条件判断</li>
                    <li><strong>不透明谓词</strong>：添加复杂但可预测的条件表达式</li>
                    <li><strong>循环转换</strong>：修改循环结构，使其更难理解</li>
                  </ul>
                </div>
                
                <div className="feature-item">
                  <h3 className="feature-title">字符串加密</h3>
                  <p>加密代码中的字符串常量，防止敏感信息泄露和字符串搜索。</p>
                  <ul>
                    <li><strong>运行时解密</strong>：字符串在运行时才被解密</li>
                    <li><strong>多层加密</strong>：使用多种算法组合加密</li>
                    <li><strong>自定义密钥</strong>：支持使用自定义密钥进行加密</li>
                  </ul>
                </div>
                
                <div className="feature-item">
                  <h3 className="feature-title">代码加壳</h3>
                  <p>为应用程序添加保护层，防止直接访问和修改字节码。</p>
                  <ul>
                    <li><strong>类加载器隔离</strong>：使用自定义类加载器加载加密的类</li>
                    <li><strong>内存保护</strong>：防止内存中的类被转储</li>
                    <li><strong>代码注入</strong>：在运行时动态生成和修改代码</li>
                  </ul>
                </div>
                
                <div className="feature-item">
                  <h3 className="feature-title">反调试保护</h3>
                  <p>检测和防止调试器附加，增强运行时安全性。</p>
                  <ul>
                    <li><strong>调试器检测</strong>：检测常见的Java调试器</li>
                    <li><strong>时间检测</strong>：检测代码执行时间异常</li>
                    <li><strong>环境检测</strong>：检测虚拟机和系统环境</li>
                  </ul>
                </div>
                
                <div className="feature-item">
                  <h3 className="feature-title">资源加密</h3>
                  <p>加密应用程序中的资源文件，防止未授权访问。</p>
                  <ul>
                    <li><strong>配置文件加密</strong>：加密properties和XML配置文件</li>
                    <li><strong>资源文件保护</strong>：保护图像、音频等资源</li>
                    <li><strong>自定义资源加载器</strong>：使用自定义加载器加载加密资源</li>
                  </ul>
                </div>
              </div>
            )}
            
            {activeTab === 'usage' && (
              <div className="docs-section">
                <h2 className="docs-title">使用指南</h2>
                <p>本指南将详细介绍如何配置和使用Java混淆器的各项功能。</p>
                
                <h3 className="docs-subtitle">基本配置</h3>
                <p>在使用Java混淆器时，您可以根据需要调整以下基本配置：</p>
                
                <div className="config-item">
                  <h4>混淆级别</h4>
                  <p>选择适合您项目的混淆级别：</p>
                  <ul>
                    <li><strong>低级别</strong>：仅进行基本的名称混淆，对性能影响最小</li>
                    <li><strong>中级别</strong>：平衡保护与性能，适合大多数项目</li>
                    <li><strong>高级别</strong>：应用所有可用的混淆技术，提供最大保护</li>
                  </ul>
                </div>
                
                <h3 className="docs-subtitle">高级配置</h3>
                
                <div className="config-item">
                  <h4>保留项配置</h4>
                  <p>指定不应被混淆的类、方法或包：</p>
                  <ul>
                    <li><strong>保留包名</strong>：指定不应被混淆的包，例如公共API</li>
                    <li><strong>排除类</strong>：指定完全排除在混淆过程之外的类</li>
                    <li><strong>保留方法</strong>：指定不应被混淆的方法，如序列化相关方法</li>
                  </ul>
                  <p>示例配置：</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`// 保留以下包不被混淆
com.example.api.*
com.example.model.*

// 排除以下类
com.example.Main
com.example.util.Helper`}
                  </SyntaxHighlighter>
                </div>
                
                <div className="config-item">
                  <h4>自定义混淆字典</h4>
                  <p>您可以提供自定义的混淆字典，用于替换类、方法和变量名：</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`// 自定义混淆字典示例
a
b
c
foo
bar
temp
x
y
z`}
                  </SyntaxHighlighter>
                </div>
                
                <h3 className="docs-subtitle">命令行使用</h3>
                <p>如果您使用独立版本，可以通过命令行运行Java混淆器：</p>
                <SyntaxHighlighter language="bash" style={docco}>
                  {`java -jar java-obfuscator.jar --input MyApp.jar --output MyApp-obfuscated.jar --level medium`}
                </SyntaxHighlighter>
                
                <h3 className="docs-subtitle">Maven插件配置</h3>
                <p>在Maven项目中，您可以将Java混淆器集成到构建过程中：</p>
                <SyntaxHighlighter language="xml" style={docco}>
                  {`<plugin>
  <groupId>com.example</groupId>
  <artifactId>java-obfuscator-maven-plugin</artifactId>
  <version>1.0.0</version>
  <configuration>
    <level>medium</level>
    <preservePackages>
      <package>com.example.api</package>
    </preservePackages>
    <excludeClasses>
      <class>com.example.Main</class>
    </excludeClasses>
  </configuration>
  <executions>
    <execution>
      <phase>package</phase>
      <goals>
        <goal>obfuscate</goal>
      </goals>
    </execution>
  </executions>
</plugin>`}
                  </SyntaxHighlighter>
              </div>
            )}
            
            {activeTab === 'api' && (
              <div className="docs-section">
                <h2 className="docs-title">API文档</h2>
                <p>Java混淆器提供了一套完整的API，允许您以编程方式集成和使用混淆功能。</p>
                
                <h3 className="docs-subtitle">核心API</h3>
                <p>以下是Java混淆器的核心API类：</p>
                
                <div className="api-item">
                  <h4>JavaObfuscator</h4>
                  <p>主要的混淆器类，用于配置和执行混淆过程。</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`import com.example.obfuscator.JavaObfuscator;
import com.example.obfuscator.config.ObfuscationConfig;

// 创建混淆器实例
JavaObfuscator obfuscator = new JavaObfuscator();

// 配置混淆选项
ObfuscationConfig config = new ObfuscationConfig();
config.setLevel(ObfuscationLevel.MEDIUM);
config.addPreservePackage("com.example.api");
config.addExcludeClass("com.example.Main");

// 执行混淆
obfuscator.obfuscate("input.jar", "output.jar", config);`}
                  </SyntaxHighlighter>
                </div>
                
                <div className="api-item">
                  <h4>ObfuscationConfig</h4>
                  <p>用于配置混淆选项的类。</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`// 创建配置
ObfuscationConfig config = new ObfuscationConfig();

// 设置混淆级别
config.setLevel(ObfuscationLevel.HIGH);

// 启用/禁用特定功能
config.setRenameClasses(true);
config.setRenameVariables(true);
config.setControlFlowObfuscation(true);
config.setStringEncryption(true);
config.setDeadCodeInsertion(false);

// 添加保留项
config.addPreservePackage("com.example.api");
config.addExcludeClass("com.example.Main");
config.addPreserveMethod("toString");
config.addPreserveMethod("equals");
config.addPreserveMethod("hashCode");`}
                  </SyntaxHighlighter>
                </div>
                
                <h3 className="docs-subtitle">自定义混淆器</h3>
                <p>您可以通过实现以下接口来创建自定义混淆器：</p>
                
                <div className="api-item">
                  <h4>Obfuscator接口</h4>
                  <p>所有混淆器组件必须实现的基本接口。</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`public interface Obfuscator {
    /**
     * 对给定的类执行混淆
     * @param classNode 要混淆的类
     * @param context 混淆上下文
     */
    void obfuscate(ClassNode classNode, ObfuscationContext context);
}`}
                  </SyntaxHighlighter>
                </div>
                
                <div className="api-item">
                  <h4>自定义混淆器示例</h4>
                  <p>以下是一个简单的自定义混淆器示例：</p>
                  <SyntaxHighlighter language="java" style={docco}>
                    {`import com.example.obfuscator.api.Obfuscator;
import com.example.obfuscator.api.ObfuscationContext;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

public class CustomMethodObfuscator implements Obfuscator {
    @Override
    public void obfuscate(ClassNode classNode, ObfuscationContext context) {
        // 对类中的每个方法进行处理
        for (MethodNode method : classNode.methods) {
            // 跳过构造函数和静态初始化块
            if (method.name.equals("<init>") || method.name.equals("<clinit>")) {
                continue;
            }
            
            // 执行自定义混淆逻辑
            // ...
        }
    }
}`}
                  </SyntaxHighlighter>
                </div>
                
                <h3 className="docs-subtitle">REST API</h3>
                <p>Java混淆器还提供了REST API，允许您通过HTTP请求使用混淆服务：</p>
                
                <div className="api-item">
                  <h4>上传并混淆代码</h4>
                  <p>端点：<code>POST /api/obfuscate</code></p>
                  <p>请求示例：</p>
                  <SyntaxHighlighter language="javascript" style={docco}>
                    {`// 使用fetch API
const formData = new FormData();
formData.append('file', fileInput.files[0]);
formData.append('level', 'medium');
formData.append('renameClasses', 'true');
formData.append('renameVariables', 'true');
formData.append('controlFlowObfuscation', 'true');
formData.append('stringEncryption', 'true');

fetch('https://api.javaobfuscator.com/api/obfuscate', {
  method: 'POST',
  body: formData
})
.then(response => response.blob())
.then(blob => {
  // 处理返回的混淆后的文件
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'obfuscated.jar';
  a.click();
})
.catch(error => console.error('Error:', error));`}
                  </SyntaxHighlighter>
                </div>
              </div>
            )}
            
            {activeTab === 'examples' && (
              <div className="docs-section">
                <h2 className="docs-title">示例代码</h2>
                <p>以下示例展示了Java代码在混淆前后的对比，帮助您了解混淆的效果。</p>
                
                <div className="example-item">
                  <h3 className="example-title">示例1：基本类混淆</h3>
                  <div className="code-comparison">
                    <div className="code-block">
                      <h4>混淆前</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public class UserService {
    private UserRepository userRepository;
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    public User findUserById(long userId) {
        return userRepository.findById(userId);
    }
    
    public List<User> findAllActiveUsers() {
        return userRepository.findByStatus("active");
    }
}`}
                      </SyntaxHighlighter>
                    </div>
                    
                    <div className="code-block">
                      <h4>混淆后</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public class a {
    private b c;
    
    public a(b d) {
        this.c = d;
    }
    
    public e a(long f) {
        return c.a(f);
    }
    
    public List<e> b() {
        return c.a("active");
    }
}`}
                      </SyntaxHighlighter>
                    </div>
                  </div>
                </div>
                
                <div className="example-item">
                  <h3 className="example-title">示例2：字符串加密</h3>
                  <div className="code-comparison">
                    <div className="code-block">
                      <h4>混淆前</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public class ConfigManager {
    private static final String API_KEY = "abcd1234efgh5678";
    private static final String API_SECRET = "xyzw9876abcd5432";
    
    public static String getApiUrl() {
        return "https://api.example.com/v1";
    }
    
    public static Map<String, String> getAuthHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-API-Key", API_KEY);
        headers.put("X-API-Secret", API_SECRET);
        return headers;
    }
}`}
                      </SyntaxHighlighter>
                    </div>
                    
                    <div className="code-block">
                      <h4>混淆后</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public class a {
    private static final String b = a("8f7d56a1e2c4b3");
    private static final String c = a("3e9a2c7b5d8f1e");
    
    public static String a() {
        return a("7b3c9d2e5f8a1b4c6d7e9f2a3b5c8d1e");
    }
    
    public static Map<String, String> b() {
        Map<String, String> a = new HashMap<>();
        a.put(a("9c7b5a3d1e8f2c"), b);
        a.put(a("4e2d6c8b1a3f5e"), c);
        return a;
    }
    
    private static String a(String a) {
        // 复杂的解密逻辑
        char[] b = a.toCharArray();
        StringBuilder c = new StringBuilder();
        for (int d = 0; d < b.length; d++) {
            c.append((char) (b[d] ^ ((d * 7) % 256)));
        }
        return c.toString();
    }
}`}
                      </SyntaxHighlighter>
                    </div>
                  </div>
                </div>
                
                <div className="example-item">
                  <h3 className="example-title">示例3：控制流混淆</h3>
                  <div className="code-comparison">
                    <div className="code-block">
                      <h4>混淆前</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public int calculateDiscount(User user, Order order) {
    int discount = 0;
    
    if (user.isPremium()) {
        discount += 10;
    }
    
    if (order.getTotal() > 100) {
        discount += 5;
    }
    
    if (order.getItems().size() > 5) {
        discount += 5;
    }
    
    return Math.min(discount, 20);
}`}
                      </SyntaxHighlighter>
                    </div>
                    
                    <div className="code-block">
                      <h4>混淆后</h4>
                      <SyntaxHighlighter language="java" style={docco}>
                        {`public int a(e f, d g) {
    int h = 0;
    int i = 0;
    int j = 5;
    
    while (true) {
        switch (i) {
            case 0:
                if (a(f, g, 8271) != 0) {
                    i = 3;
                } else {
                    i = 1;
                }
                break;
            case 1:
                if (b(f, g, 1592) != 0) {
                    i = 4;
                } else {
                    i = 2;
                }
                break;
            case 2:
                if (c(f, g, 3847) != 0) {
                    i = 5;
                } else {
                    i = 6;
                }
                break;
            case 3:
                h += 10;
                i = 1;
                break;
            case 4:
                h += 5;
                i = 2;
                break;
            case 5:
                h += 5;
                i = 6;
                break;
            case 6:
                return Math.min(h, 20);
            default:
                throw new RuntimeException();
        }
    }
}

private int a(e a, d b, int c) {
    return a.a() ? 1 : 0;
}

private int b(e a, d b, int c) {
    return b.a() > 100 ? 1 : 0;
}

private int c(e a, d b, int c) {
    return b.b().size() > 5 ? 1 : 0;
}`}
                      </SyntaxHighlighter>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'faq' && (
              <div className="docs-section">
                <h2 className="docs-title">常见问题</h2>
                
                <div className="faq-item">
                  <h3 className="faq-question">混淆会影响程序性能吗？</h3>
                  <div className="faq-answer">
                    <p>混淆可能会对程序性能产生一定影响，但这取决于所选择的混淆级别和技术：</p>
                    <ul>
                      <li><strong>低级别混淆</strong>：主要进行名称混淆，对性能几乎没有影响</li>
                      <li><strong>中级别混淆</strong>：包括一些控制流混淆和字符串加密，可能会导致5-10%的性能下降</li>
                      <li><strong>高级别混淆</strong>：应用所有保护技术，可能会导致10-20%的性能下降</li>
                    </ul>
                    <p>如果性能是关键考虑因素，建议使用低级别或中级别混淆，并在关键性能路径上排除特定的类。</p>
                  </div>
                </div>
                
                <div className="faq-item">
                  <h3 className="faq-question">混淆后的代码是否可以调试？</h3>
                  <div className="faq-answer">
                    <p>混淆后的代码调试会变得更加困难，因为：</p>
                    <ul>
                      <li>类、方法和变量名被替换为无意义的标识符</li>
                      <li>控制流被修改，使得代码执行路径不直观</li>
                      <li>如果启用了调试保护功能，调试器可能无法正常附加</li>
                    </ul>
                    <p>如果需要调试混淆后的代码，建议：</p>
                    <ul>
                      <li>保留源代码映射文件（如果混淆工具支持）</li>
                      <li>在开发环境中使用未混淆的版本</li>
                      <li>只在生产环境中部署混淆后的版本</li>
                    </ul>
                  </div>
                </div>
                
                <div className="faq-item">
                  <h3 className="faq-question">混淆是否会破坏反射和序列化？</h3>
                  <div className="faq-answer">
                    <p>是的，如果不正确配置，混淆可能会破坏依赖反射和序列化的功能：</p>
                    <ul>
                      <li><strong>反射</strong>：如果代码使用字符串形式的类名和方法名进行反射调用，混淆后这些名称将发生变化</li>
                      <li><strong>序列化</strong>：混淆可能会改变类的结构，影响序列化和反序列化过程</li>
                    </ul>
                    <p>解决方案：</p>
                    <ul>
                      <li>在混淆配置中保留使用反射的类和方法</li>
                      <li>保留所有可序列化类的结构</li>
                      <li>使用注解（如@Keep）标记不应被混淆的元素</li>
                      <li>为反射调用创建映射文件，在运行时转换名称</li>
                    </ul>
                  </div>
                </div>
                
                <div className="faq-item">
                  <h3 className="faq-question">混淆后的代码是否100%安全？</h3>
                  <div className="faq-answer">
                    <p>混淆可以显著提高代码的安全性，但不能提供100%的保护：</p>
                    <ul>
                      <li>混淆主要是增加逆向工程的难度和成本</li>
                      <li>对于有足够资源和专业知识的攻击者，任何混淆最终都可能被破解</li>
                      <li>混淆应该是整体安全策略的一部分，而不是唯一的保护措施</li>
                    </ul>
                    <p>为获得最佳保护，建议：</p>
                    <ul>
                      <li>结合使用多种保护技术，如混淆、加壳、加密和许可验证</li>
                      <li>将敏感逻辑移至服务器端</li>
                      <li>定期更新混淆技术和安全措施</li>
                    </ul>
                  </div>
                </div>
                
                <div className="faq-item">
                  <h3 className="faq-question">混淆是否适用于所有类型的Java应用？</h3>
                  <div className="faq-answer">
                    <p>混淆可以应用于大多数Java应用，但某些类型的应用可能需要特殊考虑：</p>
                    <ul>
                      <li><strong>Android应用</strong>：需要使用专门的Android混淆工具（如ProGuard或R8）</li>
                      <li><strong>库和框架</strong>：需要保留公共API，只混淆内部实现</li>
                      <li><strong>Spring Boot应用</strong>：需要保留配置类和依赖注入相关的元素</li>
                      <li><strong>使用动态加载的应用</strong>：需要特别注意类加载器和资源访问</li>
                    </ul>
                    <p>我们的混淆工具提供了针对不同应用类型的预设配置，可以帮助您正确设置混淆选项。</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Documentation;
