import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = ({ serverConnected = false }) => {
  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">保护您的Java代码安全</h1>
            <p className="hero-subtitle">
              专业的Java代码混淆和加壳工具，防止逆向工程，保护您的知识产权
            </p>
          <div className="hero-buttons">
            <Link to="/tool" className="btn btn-primary">开始使用</Link>
            <Link to="/docs" className="btn btn-secondary">了解更多</Link>
          </div>
          
          {!serverConnected && (
            <div className="server-warning">
              <i className="fas fa-exclamation-triangle"></i>
              <p>后端服务器未连接，部分功能可能不可用。</p>
            </div>
          )}
          </div>
          <div className="hero-image">
            <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Java代码保护" />
          </div>
        </div>
      </section>

      <section className="features-section">
        <div className="container">
          <h2 className="section-title">强大的混淆功能</h2>
          <p className="section-subtitle">全方位保护您的Java应用程序</p>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-random"></i>
              </div>
              <h3 className="feature-title">名称混淆</h3>
              <p className="feature-description">
                重命名类、方法和变量，使反编译后的代码难以理解
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-code-branch"></i>
              </div>
              <h3 className="feature-title">控制流混淆</h3>
              <p className="feature-description">
                修改程序的执行流程，增加代码复杂度，阻碍静态分析
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-shield-alt"></i>
              </div>
              <h3 className="feature-title">字符串加密</h3>
              <p className="feature-description">
                加密代码中的字符串常量，防止敏感信息泄露
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-lock"></i>
              </div>
              <h3 className="feature-title">代码加壳</h3>
              <p className="feature-description">
                为应用程序添加保护层，防止直接访问和修改字节码
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-puzzle-piece"></i>
              </div>
              <h3 className="feature-title">资源加密</h3>
              <p className="feature-description">
                加密应用程序中的资源文件，防止未授权访问
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-bug-slash"></i>
              </div>
              <h3 className="feature-title">反调试保护</h3>
              <p className="feature-description">
                检测和防止调试器附加，增强运行时安全性
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="how-it-works">
        <div className="container">
          <h2 className="section-title">工作原理</h2>
          <p className="section-subtitle">简单三步，保护您的Java代码</p>
          
          <div className="steps">
            <div className="step">
              <div className="step-number">1</div>
              <div className="step-content">
                <h3 className="step-title">上传代码</h3>
                <p className="step-description">
                  上传您的Java源代码或编译后的JAR/WAR文件
                </p>
              </div>
            </div>
            
            <div className="step">
              <div className="step-number">2</div>
              <div className="step-content">
                <h3 className="step-title">配置混淆选项</h3>
                <p className="step-description">
                  根据需要选择混淆级别和保护策略
                </p>
              </div>
            </div>
            
            <div className="step">
              <div className="step-number">3</div>
              <div className="step-content">
                <h3 className="step-title">下载保护后的代码</h3>
                <p className="step-description">
                  获取混淆和加壳后的代码，直接部署使用
                </p>
              </div>
            </div>
          </div>
          
          <div className="cta-container">
            <Link to="/tool" className="btn btn-primary">立即开始</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
