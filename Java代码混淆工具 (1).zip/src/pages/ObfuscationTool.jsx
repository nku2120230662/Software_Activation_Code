import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { obfuscateCode, getObfuscationOptions } from '../services/api';
import { downloadFile, formatFileSize, isValidJavaFile } from '../utils/fileUtils';
import './ObfuscationTool.css';

const ObfuscationTool = () => {
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [settings, setSettings] = useState({
    renameVariables: true,
    renameClasses: true,
    renamePackages: false,
    controlFlowObfuscation: true,
    stringEncryption: true,
    deadCodeInsertion: false,
    debugProtection: true,
    resourceEncryption: false,
    obfuscationLevel: 'medium',
    preservePackages: '',
    excludeClasses: ''
  });
  const [serverOptions, setServerOptions] = useState(null);
  const [error, setError] = useState(null);

  // 组件加载时获取服务器配置选项
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const response = await getObfuscationOptions();
        setServerOptions(response.data);
      } catch (err) {
        console.error('Failed to fetch obfuscation options:', err);
        setError('无法连接到服务器，请检查后端服务是否运行');
      }
    };

    fetchOptions();
  }, []);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (isValidJavaFile(selectedFile)) {
        setFile(selectedFile);
        setFileName(selectedFile.name);
        setFileSize(formatFileSize(selectedFile.size));
      } else {
        toast.error('请上传Java源文件(.java)或编译后的文件(.jar, .war, .class)');
        e.target.value = null;
      }
    }
  };

  const handleSettingChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings({
      ...settings,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      if (isValidJavaFile(droppedFile)) {
        setFile(droppedFile);
        setFileName(droppedFile.name);
        setFileSize(formatFileSize(droppedFile.size));
      } else {
        toast.error('请上传Java源文件(.java)或编译后的文件(.jar, .war, .class)');
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file) {
      toast.error('请先上传文件');
      return;
    }
    
    setIsProcessing(true);
    setUploadProgress(0);
    
    try {
      // 调用API上传文件并进行混淆
      const response = await obfuscateCode(file, settings, {
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percentCompleted);
        }
      });
      
      // 处理成功，下载混淆后的文件
      const outputFileName = `obfuscated_${fileName}`;
      downloadFile(response.data, outputFileName);
      
      toast.success('代码混淆成功！');
    } catch (error) {
      console.error('Obfuscation failed:', error);
      
      if (error.response) {
        // 服务器返回错误
        if (error.response.data instanceof Blob) {
          // 如果错误响应是Blob，可能包含错误信息
          const reader = new FileReader();
          reader.onload = () => {
            try {
              const errorData = JSON.parse(reader.result);
              toast.error(`混淆失败: ${errorData.message || '未知错误'}`);
            } catch (e) {
              toast.error('混淆失败: 服务器返回未知错误');
            }
          };
          reader.readAsText(error.response.data);
        } else {
          toast.error(`混淆失败: ${error.response.data.message || '未知错误'}`);
        }
      } else if (error.request) {
        // 请求发送但没有收到响应
        toast.error('混淆失败: 无法连接到服务器');
      } else {
        // 请求设置出错
        toast.error(`混淆失败: ${error.message}`);
      }
    } finally {
      setIsProcessing(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="obfuscation-tool">
      <div className="container">
        <h1 className="page-title">Java代码混淆工具</h1>
        <p className="page-description">
          上传您的Java代码，配置混淆选项，获取保护后的代码
        </p>
        
        <div className="tool-container">
          <div className="upload-section">
            <h2 className="section-heading">上传文件</h2>
            <div 
              className="file-drop-area"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            >
              {error && (
                <div className="server-error">
                  <i className="fas fa-exclamation-triangle"></i>
                  <p>{error}</p>
                  <button 
                    className="btn btn-secondary"
                    onClick={() => window.location.reload()}
                  >
                    重试连接
                  </button>
                </div>
              )}
              
              {!error && !file ? (
                <>
                  <i className="fas fa-cloud-upload-alt"></i>
                  <p>拖放文件到这里或点击上传</p>
                  <p className="file-types">支持的文件类型: .java, .jar, .war, .class</p>
                  <input 
                    type="file" 
                    id="file-upload" 
                    onChange={handleFileChange}
                    accept=".java,.jar,.war,.class"
                  />
                  <label htmlFor="file-upload" className="btn btn-primary">选择文件</label>
                </>
              ) : !error && file ? (
                <div className="file-info">
                  <i className="fas fa-file-code"></i>
                  <p className="file-name">{fileName}</p>
                  <p className="file-size">{fileSize}</p>
                  <button 
                    className="btn btn-secondary"
                    onClick={() => {
                      setFile(null);
                      setFileName('');
                      setFileSize('');
                    }}
                  >
                    移除文件
                  </button>
                </div>
              ) : null}
            </div>
          </div>
          
          <div className="settings-section">
            <h2 className="section-heading">混淆设置</h2>
            <form onSubmit={handleSubmit}>
              <div className="settings-group">
                <h3 className="settings-group-title">基本设置</h3>
                
                <div className="form-group">
                  <label>混淆级别</label>
                  <select 
                    name="obfuscationLevel"
                    value={settings.obfuscationLevel}
                    onChange={handleSettingChange}
                  >
                    <option value="low">低 - 基本保护</option>
                    <option value="medium">中 - 平衡保护与性能</option>
                    <option value="high">高 - 最大保护</option>
                  </select>
                </div>
              </div>
              
              <div className="settings-group">
                <h3 className="settings-group-title">名称混淆</h3>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="renameVariables" 
                    name="renameVariables"
                    checked={settings.renameVariables}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="renameVariables">混淆变量名</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="renameClasses" 
                    name="renameClasses"
                    checked={settings.renameClasses}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="renameClasses">混淆类名</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="renamePackages" 
                    name="renamePackages"
                    checked={settings.renamePackages}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="renamePackages">混淆包名</label>
                </div>
              </div>
              
              <div className="settings-group">
                <h3 className="settings-group-title">代码保护</h3>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="controlFlowObfuscation" 
                    name="controlFlowObfuscation"
                    checked={settings.controlFlowObfuscation}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="controlFlowObfuscation">控制流混淆</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="stringEncryption" 
                    name="stringEncryption"
                    checked={settings.stringEncryption}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="stringEncryption">字符串加密</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="deadCodeInsertion" 
                    name="deadCodeInsertion"
                    checked={settings.deadCodeInsertion}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="deadCodeInsertion">插入无效代码</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="debugProtection" 
                    name="debugProtection"
                    checked={settings.debugProtection}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="debugProtection">调试保护</label>
                </div>
                
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    id="resourceEncryption" 
                    name="resourceEncryption"
                    checked={settings.resourceEncryption}
                    onChange={handleSettingChange}
                  />
                  <label htmlFor="resourceEncryption">资源加密</label>
                </div>
              </div>
              
              <div className="settings-group">
                <h3 className="settings-group-title">高级设置</h3>
                
                <div className="form-group">
                  <label htmlFor="preservePackages">保留包名（用逗号分隔）</label>
                  <input 
                    type="text" 
                    id="preservePackages" 
                    name="preservePackages"
                    placeholder="例如: com.example.api,com.example.model"
                    value={settings.preservePackages}
                    onChange={handleSettingChange}
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="excludeClasses">排除类（用逗号分隔）</label>
                  <input 
                    type="text" 
                    id="excludeClasses" 
                    name="excludeClasses"
                    placeholder="例如: com.example.Main,com.example.util.Helper"
                    value={settings.excludeClasses}
                    onChange={handleSettingChange}
                  />
                </div>
              </div>
              
              <div className="form-actions">
                {uploadProgress > 0 && isProcessing && (
                  <div className="progress-container">
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                    <p className="progress-text">{uploadProgress}%</p>
                  </div>
                )}
                
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={!file || isProcessing || error}
                >
                  {isProcessing ? (
                    <>
                      <i className="fas fa-spinner fa-spin"></i> 处理中...
                    </>
                  ) : '开始混淆'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ObfuscationTool;
