import React from 'react';
import { Link } from 'react-router-dom';
import './About.css';

const About = () => {
  return (
    <div className="about-page">
      <div className="container">
        <section className="about-section">
          <h1 className="page-title">关于我们</h1>
          <p className="page-description">
            了解Java混淆器背后的团队和技术
          </p>
          
          <div className="about-content">
            <div className="about-image">
              <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="我们的团队" />
            </div>
            
            <div className="about-text">
              <h2 className="section-heading">我们的使命</h2>
              <p>
                在当今数字世界中，软件知识产权保护变得越来越重要。我们的使命是为Java开发者提供强大、易用的代码保护工具，帮助他们保护自己的知识产权和商业利益。
              </p>
              <p>
                我们相信，每一位开发者都应该能够保护自己的创新成果，无论是商业软件还是开源项目。通过我们的混淆和加壳技术，我们致力于提高Java应用程序的安全性，防止未授权的逆向工程和代码盗用。
              </p>
              
              <h2 className="section-heading">我们的团队</h2>
              <p>
                我们的团队由一群对软件安全充满热情的专业人士组成，包括Java开发专家、安全研究人员和用户体验设计师。团队成员来自不同的技术背景，但都有一个共同的目标：创造最好的Java代码保护解决方案。
              </p>
              <p>
                我们不断研究最新的逆向工程技术和保护方法，确保我们的工具始终领先于潜在的威胁。同时，我们也注重用户体验，努力使复杂的安全技术变得简单易用。
              </p>
            </div>
          </div>
        </section>
        
        <section className="technology-section">
          <h2 className="section-title">我们的技术</h2>
          <p className="section-subtitle">
            探索Java混淆器背后的核心技术
          </p>
          
          <div className="tech-cards">
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-code"></i>
              </div>
              <h3 className="tech-title">ASM字节码操作</h3>
              <p className="tech-description">
                我们使用ASM框架直接操作Java字节码，实现高效的代码转换和混淆，同时保持代码的功能完整性。
              </p>
            </div>
            
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-shield-alt"></i>
              </div>
              <h3 className="tech-title">多层加密算法</h3>
              <p className="tech-description">
                采用多层加密算法保护字符串常量和资源文件，使用动态密钥生成和上下文相关的解密机制。
              </p>
            </div>
            
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-random"></i>
              </div>
              <h3 className="tech-title">控制流分析与转换</h3>
              <p className="tech-description">
                通过复杂的控制流分析和转换技术，重构代码执行路径，增加逆向工程的难度。
              </p>
            </div>
            
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-cogs"></i>
              </div>
              <h3 className="tech-title">自定义类加载器</h3>
              <p className="tech-description">
                使用自定义类加载器实现代码加壳和运行时保护，防止内存中的类被转储和分析。
              </p>
            </div>
            
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-fingerprint"></i>
              </div>
              <h3 className="tech-title">环境检测与防篡改</h3>
              <p className="tech-description">
                实时检测运行环境，识别调试器和虚拟机，防止代码被篡改和非授权执行。
              </p>
            </div>
            
            <div className="tech-card">
              <div className="tech-icon">
                <i className="fas fa-cloud"></i>
              </div>
              <h3 className="tech-title">云端保护服务</h3>
              <p className="tech-description">
                提供云端保护服务，实现远程验证和动态更新保护策略，增强软件的长期安全性。
              </p>
            </div>
          </div>
        </section>
        
        <section className="values-section">
          <div className="values-content">
            <h2 className="section-heading">我们的价值观</h2>
            <ul className="values-list">
              <li className="value-item">
                <div className="value-icon">
                  <i className="fas fa-lock"></i>
                </div>
                <div className="value-text">
                  <h3>安全第一</h3>
                  <p>我们始终将安全性放在首位，不断研究和应用最先进的保护技术。</p>
                </div>
              </li>
              
              <li className="value-item">
                <div className="value-icon">
                  <i className="fas fa-user-shield"></i>
                </div>
                <div className="value-text">
                  <h3>用户隐私</h3>
                  <p>我们尊重用户隐私，不收集或分析用户的代码内容，确保知识产权完全属于用户。</p>
                </div>
              </li>
              
              <li className="value-item">
                <div className="value-icon">
                  <i className="fas fa-lightbulb"></i>
                </div>
                <div className="value-text">
                  <h3>持续创新</h3>
                  <p>我们不断创新和改进我们的技术，跟上不断变化的安全威胁和用户需求。</p>
                </div>
              </li>
              
              <li className="value-item">
                <div className="value-icon">
                  <i className="fas fa-hands-helping"></i>
                </div>
                <div className="value-text">
                  <h3>用户支持</h3>
                  <p>我们提供全面的技术支持和文档，帮助用户充分利用我们的工具。</p>
                </div>
              </li>
            </ul>
          </div>
          
          <div className="values-image">
            <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="我们的价值观" />
          </div>
        </section>
        
        <section className="contact-section">
          <h2 className="section-title">联系我们</h2>
          <p className="section-subtitle">
            有任何问题或建议？我们很乐意听取您的意见
          </p>
          
          <div className="contact-cards">
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-envelope"></i>
              </div>
              <h3 className="contact-title">电子邮件</h3>
              <p className="contact-info">
                <a href="mailto:contact@javaobfuscator.com">contact@javaobfuscator.com</a>
              </p>
            </div>
            
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-phone"></i>
              </div>
              <h3 className="contact-title">电话</h3>
              <p className="contact-info">
                +86 123 4567 8910
              </p>
            </div>
            
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <h3 className="contact-title">地址</h3>
              <p className="contact-info">
                中国杭州市西湖区科技园区88号
              </p>
            </div>
          </div>
          
          <div className="cta-container">
            <Link to="/tool" className="btn btn-primary">开始使用</Link>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;
